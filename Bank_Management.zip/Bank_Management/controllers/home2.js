var express = require('express');
var router	= express.Router();
var userModel		= require.main.require('./models/user-model');


router.get('*' , function(req , res , next){
	if(req.cookies['username'] == null){
		res.redirect('/login');
	}else{
		next();
	}
});

router.get('/', function(req, res){
	
	userModel.getByUname(req.cookies['username'] , function(result){
		res.render('home2/index' , {user: result});
	});
});

router.get('/myprofile', function(req, res){
	
	userModel.getByUname(req.cookies['username'] , function(result){
		res.render('home2/myprofile' , {user: result});
	});
});



router.get('/post' , function(req , res){
	res.render('home2/post');
});


router.post("/post" , function(req , res){
	var info = {
		id: req.params.id ,
		country: req.body.country ,
		place: req.body.place ,
		cost: req.body.cost 
		
	};

	userModel.insertforinfo(info , function(status){
		//where the 'user' comes from??
		if(status){
			res.redirect('/home2/req_info')
		}else{
			res.redirect('/home2/post')
		}
	})
})

router.get('/req_info' , function(req , res){

	userModel.InfogetAll(function(results){
		if(results.length > 0){
			res.render('home2/req_info' , {userlist: results});
		}else{
			res.redirect('/home2/req_info');
		}
		
	});
});

router.get('/approve_info' , function(req , res){

	userModel.ApproveInfo_Scout(function(results){
		if(results.length > 0){
			res.render('home2/approve_info' , {userlist: results});
		}else{
			res.redirect('/home2/post');
		}
		
	});
});



module.exports = router;