const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const app = express();
var exUpload 	= require('express-fileupload')
var exSession 	= require('express-session');


const mysql = require('mysql');
 


const connection=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'mobibank'
});
 
connection.connect(function(error){
    if(!!error) console.log(error);
    else console.log('Database Connected!');
});


//set views file
app.set('views',path.join(__dirname,'views'));
			
//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));




//get all employess info
app.get('/',(req, res) => {
    
    let sql = "SELECT * FROM user";
    let query = connection.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('user_index', {
            title : 'Online Mobile Banking System (Mobile Wallet Service)',
            user : rows
            
        });
    });
});
//getAll
app.get('/getAll',(req, res) => {
    
    let sql = "SELECT * FROM user";
    let query = connection.query(sql, (err, rows) => {
        if(err) throw err;
        res.render('user_getAll', {
            title : 'ALL EMPLOYESS',
            user : rows
            
        });
    });
});
//Add New Employee
app.get('/add',(req, res) => {
    //res.send('New User Form Page');
    res.render('user_add', {
        title : 'New Employee Form Page'
    });
});
//save button
app.post('/save',(req, res) => { 
    let data = {Id: req.body.Id, UserName: req.body.UserName, Name: req.body.Name,Password: req.body.Password,Email: req.body.Email,Gender: req.body.Gender,UserType: req.body.UserType,Address: req.body.Address             };
    let sql = "INSERT INTO user SET ?";
    let query = connection.query(sql, data,(err, results) => {
      if(err) throw err;
      res.redirect('/');
    });
});
 
//edit or update
app.get('/edit/:Id',(req, res) => {
    const Id = req.params.Id;
    let sql = `Select * from user where Id = ${Id}`;
    let query = connection.query(sql,(err, result) => {
        if(err) throw err;
        res.render('user_edit', {
            title : 'Edit Operation',
            user : result[0]
        });
    });
});

app.post('/update',(req, res) => {
    const Id = req.body.Id;
    let sql = "update user SET Id='"+req.body.Id+"',  UserName='"+req.body.UserName+"',  Name='"+req.body.Name+"',  Password='"+req.body.Password+"' ,  Email='"+req.body.Email+"'  ,  Gender='"+req.body.Gender+"' ,  UserType='"+req.body.UserType+"' ,  Address='"+req.body.Address+"'         where id ="+Id;
    let query = connection.query(sql,(err, results) => {
      if(err) throw err;
      res.redirect('/');
    });
});
 


//Detete operation
app.get('/delete/:Id',(req, res) => {
    const Id = req.params.Id;
    let sql = `DELETE from user where Id = ${Id}`;
    let query = connection.query(sql,(err, result) => {
        if(err) throw err;
        res.redirect('/');
    });
});





// Server Listening
app.listen(3000, () => {
    console.log('Server is running at port 3000');
});
 
